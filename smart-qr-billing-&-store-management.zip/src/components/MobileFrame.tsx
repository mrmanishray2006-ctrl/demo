import React, { useState, useEffect } from "react";
import { Monitor, Smartphone, Sparkles, RefreshCw, Layers, ShieldCheck, User } from "lucide-react";

interface MobileFrameProps {
  children: React.ReactNode;
  activeRole: "owner" | "customer";
  onRoleSwitch: (role: "owner" | "customer") => void;
  currentUser: { name: string; email: string; role: string } | null;
  onLogout: () => void;
}

export default function MobileFrame({
  children,
  activeRole,
  onRoleSwitch,
  currentUser,
  onLogout
}: MobileFrameProps) {
  const [time, setTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, "0");
      const ampm = hours >= 12 ? "PM" : "AM";
      hours = hours % 12 || 12;
      setTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-lg mx-auto">
      {/* Simulation Controller Topbar */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-2xl p-4 mb-4 border border-slate-700/60 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600/20 text-indigo-400 rounded-lg">
            <Layers className="w-5 h-5 animate-pulse-slow" />
          </div>
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-heading">
              Role Simulator Controls
            </h3>
            <p className="text-sm font-bold text-white">
              Currently: {activeRole === "owner" ? "🏪 Owner Dashboard" : "🛍️ Customer App"}
            </p>
          </div>
        </div>

        {/* Quick Swapping Buttons */}
        <div className="flex gap-2">
          <button
            onClick={() => onRoleSwitch("owner")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeRole === "owner"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Owner Mode
          </button>
          <button
            onClick={() => onRoleSwitch("customer")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeRole === "customer"
                ? "bg-teal-600 text-white shadow-md shadow-teal-600/20"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Customer Mode
          </button>
        </div>
      </div>

      {/* Actual Mobile Phone Frame */}
      <div className="relative w-full aspect-[9/19.5] max-w-[390px] mx-auto bg-slate-950 rounded-[50px] p-3.5 border-[6px] border-slate-800 shadow-2xl iphone-glow ring-1 ring-slate-700/50 flex flex-col overflow-hidden">
        
        {/* Notch / Dynamic Island */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 w-28 h-7 bg-black rounded-full z-50 flex items-center justify-around px-2.5">
          <div className="w-2.5 h-2.5 bg-slate-900 rounded-full border border-slate-800/80"></div>
          <div className="w-8 h-1.5 bg-slate-950 rounded-full"></div>
          <div className="w-2.5 h-2.5 bg-slate-900 rounded-full border border-slate-800/80"></div>
        </div>

        {/* Mobile Status Bar */}
        <div className="h-9 flex items-center justify-between px-6 text-white text-[11px] font-medium select-none z-40 bg-slate-900/40">
          <span className="font-semibold">{time}</span>
          <div className="flex items-center gap-1.5">
            {/* Cellular reception bars */}
            <div className="flex items-end gap-[1.5px] h-2.5">
              <span className="w-[2px] h-[30%] bg-white rounded-[0.5px]"></span>
              <span className="w-[2px] h-[55%] bg-white rounded-[0.5px]"></span>
              <span className="w-[2px] h-[75%] bg-white rounded-[0.5px]"></span>
              <span className="w-[2px] h-[100%] bg-white rounded-[0.5px]"></span>
            </div>
            <span className="font-semibold text-[10px]">5G</span>
            {/* Battery icon */}
            <div className="relative w-5 h-2.5 border border-white/70 rounded-[3px] p-[1px] flex items-center">
              <div className="h-full w-[90%] bg-teal-400 rounded-[1.5px]"></div>
              <div className="absolute -right-[2px] top-1/2 -translate-y-1/2 w-[1px] h-1 bg-white/70 rounded-r-[1px]"></div>
            </div>
          </div>
        </div>

        {/* Screen Content Wrapper */}
        <div className="flex-1 rounded-[38px] bg-slate-900 text-slate-100 flex flex-col overflow-hidden relative">
          {children}
        </div>

        {/* Bottom Home Indicator Bar */}
        <div className="h-4 flex items-center justify-center pt-1 z-40 bg-slate-900/40">
          <div className="w-28 h-1 bg-white/50 rounded-full"></div>
        </div>
      </div>

      {/* Simulator Footer Details */}
      <div className="text-center mt-3 text-[10px] text-slate-500 font-mono">
        SMART QR SIMULATOR • AUTO-SYNC AT 3000ms
      </div>
    </div>
  );
}
