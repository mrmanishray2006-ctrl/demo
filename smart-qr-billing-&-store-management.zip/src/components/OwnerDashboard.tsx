import React, { useState, useEffect } from "react";
import {
  Plus,
  Edit2,
  Trash2,
  Download,
  Activity,
  AlertTriangle,
  Settings,
  CreditCard,
  Sparkles,
  Search,
  ChevronRight,
  TrendingUp,
  Store,
  QrCode,
  ListOrdered,
  Bell,
  CheckCircle,
  HelpCircle,
  RefreshCw
} from "lucide-react";
import { Product, Store as StoreType, Subscription } from "../types";

interface OwnerDashboardProps {
  store: StoreType | null;
  currentUser: any;
  onLogout: () => void;
  onRefreshGlobal: () => void;
}

export default function OwnerDashboard({
  store,
  currentUser,
  onLogout,
  onRefreshGlobal
}: OwnerDashboardProps) {
  const [activeTab, setActiveTab] = useState<"inventory" | "qrs" | "orders" | "settings" | "ai">("inventory");
  
  // Data State
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [stats, setStats] = useState<any>({
    totalSales: 0,
    dailySales: 0,
    weeklySales: 0,
    monthlySales: 0,
    totalOrders: 0,
    activeProductsCount: 0,
    lowStockAlertsCount: 0,
    categoryStats: {}
  });
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [storeSettings, setStoreSettings] = useState<any>(null);
  const [notifications, setNotifications] = useState<any[]>([]);

  // Date Filtering States
  const [dateFilterType, setDateFilterType] = useState<"all" | "today" | "7days" | "30days" | "custom">("all");
  const [customStartDate, setCustomStartDate] = useState<string>("");
  const [customEndDate, setCustomEndDate] = useState<string>("");

  // Memoized filter calculation for sales/orders history
  const filteredOrders = React.useMemo(() => {
    const now = new Date();
    return orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      if (dateFilterType === "today") {
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        return orderDate >= startOfToday;
      }
      if (dateFilterType === "7days") {
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return orderDate >= sevenDaysAgo;
      }
      if (dateFilterType === "30days") {
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return orderDate >= thirtyDaysAgo;
      }
      if (dateFilterType === "custom") {
        if (customStartDate) {
          const start = new Date(customStartDate);
          start.setHours(0, 0, 0, 0);
          if (orderDate < start) return false;
        }
        if (customEndDate) {
          const end = new Date(customEndDate);
          end.setHours(23, 59, 59, 999);
          if (orderDate > end) return false;
        }
      }
      return true;
    });
  }, [orders, dateFilterType, customStartDate, customEndDate]);

  // Memoized sales totals derived from filteredOrders
  const filteredSalesTotals = React.useMemo(() => {
    let totalRevenue = 0;
    let totalOrdersCount = 0;
    let itemsSold = 0;

    filteredOrders.forEach(order => {
      if (order.paymentStatus === "success") {
        totalRevenue += order.totalAmount;
        totalOrdersCount += 1;
        order.items?.forEach((item: any) => {
          itemsSold += item.quantity;
        });
      }
    });

    const averageOrderValue = totalOrdersCount > 0 ? Math.round(totalRevenue / totalOrdersCount) : 0;

    return {
      totalRevenue,
      totalOrdersCount,
      itemsSold,
      averageOrderValue
    };
  }, [filteredOrders]);
  
  // UI States
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiInsights, setAiInsights] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const [showNotifPanel, setShowNotifPanel] = useState(false);

  // Form states for product Addition/Editing
  const [pName, setPName] = useState("");
  const [pSku, setPSku] = useState("");
  const [pCategory, setPCategory] = useState("Bakery");
  const [pPrice, setPPrice] = useState("");
  const [pStock, setPStock] = useState("");
  const [pTax, setPTax] = useState("5");
  const [pDiscount, setPDiscount] = useState("0");
  const [pDesc, setPDesc] = useState("");
  const [pImg, setPImg] = useState("");

  // Settings form
  const [setStoreName, setSetStoreName] = useState("");
  const [setAddress, setSetAddress] = useState("");
  const [setUpiId, setSetUpiId] = useState("");
  const [setLowStock, setSetLowStock] = useState("10");

  const headers = {
    "x-user-id": currentUser?.userId || "",
    "x-user-role": currentUser?.role || ""
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch Products
      const prodRes = await fetch("/api/products", { headers });
      const prodData = await prodRes.json();
      setProducts(prodData);

      // Fetch Stats
      const statsRes = await fetch("/api/owner/sales-stats", { headers });
      const statsData = await statsRes.json();
      setStats(statsData);

      // Fetch Orders
      const orderRes = await fetch("/api/orders/history", { headers });
      const orderData = await orderRes.json();
      setOrders(orderData);

      // Fetch Subscription
      const subRes = await fetch("/api/owner/subscription", { headers });
      const subData = await subRes.json();
      setSubscription(subData);

      // Fetch Settings
      const settingsRes = await fetch("/api/owner/settings", { headers });
      const settingsData = await settingsRes.json();
      setStoreSettings(settingsData.settings);
      if (settingsData.store) {
        setSetStoreName(settingsData.store.storeName);
        setSetAddress(settingsData.store.address);
        setSetUpiId(settingsData.store.paymentUpiId);
        setSetLowStock(String(settingsData.settings.lowStockThreshold));
      }

      // Fetch Notifications
      const notifRes = await fetch("/api/notifications", { headers });
      const notifData = await notifRes.json();
      setNotifications(notifData);
    } catch (err) {
      console.error("Error fetching owner data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const handleOpenAddForm = () => {
    setEditingProduct(null);
    setPName("");
    setPSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setPCategory("Bakery");
    setPPrice("");
    setPStock("");
    setPTax("5");
    setPDiscount("0");
    setPDesc("");
    setPImg("");
    setShowAddForm(true);
  };

  const handleOpenEditForm = (p: Product) => {
    setEditingProduct(p);
    setPName(p.name);
    setPSku(p.sku);
    setPCategory(p.category);
    setPPrice(String(p.price));
    setPStock(String(p.stockQty));
    setPTax(String(p.taxPercent));
    setPDiscount(String(p.discountPercent));
    setPDesc(p.description);
    setPImg(p.imageUrl);
    setShowAddForm(true);
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const url = editingProduct ? `/api/products/${editingProduct.productId}` : "/api/products";
    const method = editingProduct ? "PUT" : "POST";

    const payload = {
      name: pName,
      sku: pSku,
      category: pCategory,
      description: pDesc,
      price: Number(pPrice),
      stockQty: Number(pStock),
      taxPercent: Number(pTax),
      discountPercent: Number(pDiscount),
      imageUrl: pImg || undefined
    };

    try {
      const res = await fetch(url, {
        method,
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to submit product");

      setShowAddForm(false);
      fetchData();
      onRefreshGlobal();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm("Are you sure you want to delete this product? Associated QR codes will be deactivated.")) return;
    try {
      const res = await fetch(`/api/products/${productId}`, {
        method: "DELETE",
        headers
      });
      if (res.ok) {
        fetchData();
        onRefreshGlobal();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/owner/settings", {
        method: "PUT",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          storeName: setStoreName,
          address: setSetAddress,
          paymentUpiId: setUpiId,
          lowStockThreshold: Number(setLowStock)
        })
      });
      if (!res.ok) throw new Error("Failed to save settings");
      alert("Store credentials and limits saved successfully!");
      fetchData();
      onRefreshGlobal();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRenewSubscription = async (plan: string, cost: number) => {
    setLoading(true);
    try {
      const res = await fetch("/api/owner/subscription/renew", {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ planName: plan, amount: cost })
      });
      if (res.ok) {
        alert(`Successfully upgraded to ${plan}! Plan is now active.`);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkNotificationsRead = async () => {
    try {
      await fetch("/api/notifications/mark-read", { method: "POST", headers });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const triggerGeminiInsights = async () => {
    setAiLoading(true);
    try {
      const res = await fetch("/api/gemini/insights", { method: "POST", headers });
      const data = await res.json();
      setAiInsights(data);
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  const handleExportCSV = () => {
    if (filteredOrders.length === 0) {
      alert("No sales history available to export for the selected date range.");
      return;
    }

    // Define headers
    const headersList = [
      "Invoice ID",
      "Date & Time",
      "Customer Name",
      "Product SKU",
      "Product Name",
      "Quantity",
      "Unit Price (INR)",
      "Line Total (INR)",
      "Order Total (INR)",
      "Payment Status"
    ];

    // Map orders to rows. One row per product item in order
    const rows: string[][] = [];

    filteredOrders.forEach(order => {
      const formattedDate = new Date(order.createdAt).toISOString().replace("T", " ").substring(0, 19);
      
      order.items.forEach((item: any) => {
        const productSku = products.find(p => p.productId === item.productId)?.sku || "N/A";
        
        const row = [
          order.orderId,
          formattedDate,
          order.customerName || "Anonymous Customer",
          productSku,
          item.productName,
          String(item.quantity),
          String(item.price),
          String(item.lineTotal),
          String(order.totalAmount),
          order.paymentStatus.toUpperCase()
        ];
        
        rows.push(row);
      });
    });

    // Convert to CSV string
    const csvContent = [
      headersList.join(","),
      ...rows.map(row => 
        row.map(val => {
          const escaped = val.replace(/"/g, '""');
          if (escaped.includes(",") || escaped.includes('"') || escaped.includes("\n")) {
            return `"${escaped}"`;
          }
          return escaped;
        }).join(",")
      )
    ].join("\n");

    // Create file download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    
    const storeNameClean = (store?.storeName || "SmartMart").replace(/[^a-z0-9]/gi, "_").toLowerCase();
    const dateStr = new Date().toISOString().slice(0, 10);
    link.setAttribute("download", `${storeNameClean}_sales_report_${dateStr}.csv`);
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-900">
      
      {/* Mini App Header */}
      <div className="h-14 bg-slate-950/80 border-b border-slate-800/80 px-4 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-2">
          <Store className="w-4 h-4 text-indigo-400" />
          <div className="text-left">
            <h1 className="text-xs font-bold text-white font-heading truncate max-w-[140px]">
              {store?.storeName || "Smart Mart"}
            </h1>
            <p className="text-[9px] text-slate-500 font-mono tracking-wider">OWNER HUB</p>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-2">
          {/* Notifications Trigger */}
          <button
            onClick={() => {
              setShowNotifPanel(!showNotifPanel);
              if (!showNotifPanel) handleMarkNotificationsRead();
            }}
            className="p-1.5 hover:bg-slate-800/80 text-slate-400 hover:text-white rounded-lg relative transition-all"
          >
            <Bell className="w-4 h-4" />
            {notifications.filter(n => !n.read).length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full"></span>
            )}
          </button>

          <button
            onClick={onLogout}
            className="text-[10px] font-bold text-rose-400 border border-rose-500/20 px-2 py-1 rounded-lg bg-rose-500/5 hover:bg-rose-500/10 transition-all"
          >
            Exit
          </button>
        </div>
      </div>

      {/* Notifications Drawer */}
      {showNotifPanel && (
        <div className="absolute top-14 left-0 right-0 max-h-56 bg-slate-950 border-b border-slate-800/80 shadow-2xl overflow-y-auto p-3 z-30">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Alerts Log</span>
            <button
              onClick={() => setShowNotifPanel(false)}
              className="text-[10px] text-indigo-400 hover:underline"
            >
              Close
            </button>
          </div>
          <div className="space-y-1.5">
            {notifications.length === 0 ? (
              <p className="text-[11px] text-slate-500 py-3 text-center">No alerts currently logged.</p>
            ) : (
              notifications.map((n, idx) => (
                <div
                  key={n.id || idx}
                  className={`p-2 rounded-lg text-[10px] border flex items-start gap-1.5 ${
                    n.type === "warning"
                      ? "bg-amber-500/10 border-amber-500/20 text-amber-300"
                      : "bg-teal-500/10 border-teal-500/20 text-teal-300"
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">{n.title}</p>
                    <p className="text-slate-400 text-[9px] mt-0.5">{n.message}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Primary Dashboard Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        
        {/* Quick Stats overview */}
        <div className="grid grid-cols-3 gap-2 shrink-0">
          <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800 text-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Today</span>
            <span className="text-xs font-bold text-emerald-400 block mt-0.5">₹{stats.dailySales}</span>
          </div>
          <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800 text-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Total Sales</span>
            <span className="text-xs font-bold text-indigo-400 block mt-0.5">₹{stats.totalSales}</span>
          </div>
          <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800 text-center relative">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Low Stock</span>
            <span className={`text-xs font-bold block mt-0.5 ${stats.lowStockAlertsCount > 0 ? "text-rose-400 animate-pulse" : "text-slate-400"}`}>
              {stats.lowStockAlertsCount}
            </span>
          </div>
        </div>

        {/* Tab content loaders */}
        {activeTab === "inventory" && (
          <div className="space-y-3">
            {/* Action Header */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search SKU or name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-950/60 border border-slate-800 rounded-xl py-1.5 pl-8 pr-3 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                onClick={handleOpenAddForm}
                className="bg-indigo-600 hover:bg-indigo-500 text-white p-2 rounded-xl transition-all shadow-md shrink-0 flex items-center justify-center"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Product Add/Edit Form Overlay */}
            {showAddForm && (
              <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-3 shadow-2xl relative">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 border-b border-slate-800 pb-2">
                  {editingProduct ? "✏️ Edit Store Product" : "➕ Add Store Product"}
                </h3>

                <form onSubmit={handleProductSubmit} className="space-y-3 text-left">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Product Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Organic Apple"
                        value={pName}
                        onChange={(e) => setPName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">SKU Code</label>
                      <input
                        type="text"
                        required
                        placeholder="FR-APP-01"
                        value={pSku}
                        onChange={(e) => setPSku(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Price (INR)</label>
                      <input
                        type="number"
                        required
                        placeholder="120"
                        value={pPrice}
                        onChange={(e) => setPPrice(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Stock Qty</label>
                      <input
                        type="number"
                        required
                        placeholder="50"
                        value={pStock}
                        onChange={(e) => setPStock(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Category</label>
                      <select
                        value={pCategory}
                        onChange={(e) => setPCategory(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-white"
                      >
                        <option value="Fruits">Fruits</option>
                        <option value="Bakery">Bakery</option>
                        <option value="Dairy">Dairy</option>
                        <option value="Beverages">Beverages</option>
                        <option value="Staples">Staples</option>
                        <option value="General">General</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">GST Tax %</label>
                      <input
                        type="number"
                        placeholder="5"
                        value={pTax}
                        onChange={(e) => setPTax(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Discount %</label>
                      <input
                        type="number"
                        placeholder="10"
                        value={pDiscount}
                        onChange={(e) => setPDiscount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Product Image URL</label>
                    <input
                      type="text"
                      placeholder="https://images.unsplash.com/..."
                      value={pImg}
                      onChange={(e) => setPImg(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[9px] font-semibold text-slate-500 block mb-0.5">Description</label>
                    <textarea
                      placeholder="Enter description..."
                      value={pDesc}
                      onChange={(e) => setPDesc(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                    />
                  </div>

                  <div className="flex gap-2 border-t border-slate-800 pt-3">
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md"
                    >
                      {submitting ? "Saving..." : "Save Product"}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Inventory List */}
            <div className="space-y-2">
              {filteredProducts.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs">No products found matching query.</div>
              ) : (
                filteredProducts.map(p => (
                  <div
                    key={p.productId}
                    className="p-3 bg-slate-950/50 rounded-2xl border border-slate-800/80 flex items-center justify-between gap-3"
                  >
                    <img
                      src={p.imageUrl}
                      alt={p.name}
                      className="w-11 h-11 rounded-lg object-cover shrink-0 bg-slate-800"
                    />
                    <div className="flex-1 min-w-0 text-left">
                      <h4 className="text-xs font-bold text-white truncate">{p.name}</h4>
                      <p className="text-[9px] font-mono text-slate-500 mt-0.5">SKU: {p.sku}</p>
                      
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-bold text-indigo-400">₹{p.price}</span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                            p.stockQty <= (storeSettings?.lowStockThreshold || 10)
                              ? "bg-rose-500/10 text-rose-400 animate-pulse"
                              : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          Stock: {p.stockQty}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEditForm(p)}
                        className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-indigo-400 rounded-lg"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(p.productId)}
                        className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-rose-400 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === "qrs" && (
          <div className="space-y-4">
            {/* Catalog Controller */}
            <div className="p-4 bg-gradient-to-br from-indigo-950/50 to-slate-950 rounded-2xl border border-indigo-500/20 text-center space-y-3">
              <div className="inline-flex p-3 bg-indigo-600/10 text-indigo-400 rounded-xl border border-indigo-500/10">
                <QrCode className="w-6 h-6" />
              </div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-heading">
                Combined QR Code PDF
              </h3>
              <p className="text-[10px] text-slate-400 max-w-xs mx-auto">
                Generate and print a catalogue page containing structured QR cards for each product with retail pricing and details.
              </p>

              <a
                href="/api/pdf/export-qrs"
                download
                className="inline-flex w-full items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-2.5 rounded-xl transition-all shadow-lg"
              >
                <Download className="w-4 h-4" />
                Download PDF Catalogue
              </a>
            </div>

            {/* Individual QRs list */}
            <div className="grid grid-cols-2 gap-3 text-left">
              {products.map(p => (
                <div key={p.productId} className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex flex-col justify-between">
                  <div>
                    <span className="text-[8px] font-bold text-indigo-400 uppercase tracking-widest">{p.category}</span>
                    <h4 className="text-[10px] font-bold text-white truncate mt-0.5">{p.name}</h4>
                  </div>
                  
                  <div className="my-2 flex justify-center bg-white p-1 rounded-lg">
                    <img src={p.qrCodeUrl} alt={p.name} className="w-24 h-24" />
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[9px] text-slate-400 font-mono tracking-tighter truncate max-w-[80px]">₹{p.price}</span>
                    <a
                      href={p.qrCodeUrl}
                      download={`${p.sku}_QR.png`}
                      className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                      title="Download image"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "orders" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider text-left">
                Sales History ({filteredOrders.length === orders.length ? orders.length : `${filteredOrders.length}/${orders.length}`})
              </h3>
              {filteredOrders.length > 0 && (
                <button
                  type="button"
                  onClick={handleExportCSV}
                  className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold px-2.5 py-1.5 rounded-xl transition-all shadow-md shrink-0"
                  title="Export accounting CSV file for the selected interval"
                >
                  <Download className="w-3 h-3" />
                  Export CSV
                </button>
              )}
            </div>

            {/* Sales Dashboard Date Filters */}
            <div className="p-3.5 bg-slate-950/40 rounded-2xl border border-slate-800/80 space-y-3 text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block">
                  📅 Sales Interval
                </span>
                <span className="text-[9px] text-slate-500 font-mono">
                  {dateFilterType === "custom" && customStartDate && customEndDate 
                    ? `${customStartDate} to ${customEndDate}` 
                    : dateFilterType.toUpperCase()}
                </span>
              </div>

              {/* Quick Select Intervals */}
              <div className="grid grid-cols-5 gap-1">
                {[
                  { value: "all", label: "All" },
                  { value: "today", label: "Today" },
                  { value: "7days", label: "7D" },
                  { value: "30days", label: "30D" },
                  { value: "custom", label: "Custom" }
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setDateFilterType(opt.value as any)}
                    className={`py-1 text-[10px] font-bold rounded-lg transition-all text-center ${
                      dateFilterType === opt.value
                        ? "bg-indigo-600 text-white"
                        : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {/* Custom Date Picker Inputs */}
              {dateFilterType === "custom" && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="text-[8px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Start Date</label>
                    <input
                      type="date"
                      value={customStartDate}
                      onChange={(e) => setCustomStartDate(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-[11px] text-white focus:outline-none focus:border-indigo-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[8px] font-bold text-slate-500 uppercase tracking-wider block mb-1">End Date</label>
                    <input
                      type="date"
                      value={customEndDate}
                      onChange={(e) => setCustomEndDate(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-[11px] text-white focus:outline-none focus:border-indigo-500 font-mono"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Filtered Sales Summary Cards */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-slate-950/30 p-2.5 rounded-xl border border-slate-800/80 text-left">
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider block">Filtered Sales</span>
                <span className="text-xs font-bold text-indigo-400 block mt-1">₹{filteredSalesTotals.totalRevenue}</span>
                <span className="text-[8px] text-slate-500 font-mono mt-0.5 block">{filteredSalesTotals.totalOrdersCount} paid</span>
              </div>
              <div className="bg-slate-950/30 p-2.5 rounded-xl border border-slate-800/80 text-left">
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider block">Items Sold</span>
                <span className="text-xs font-bold text-emerald-400 block mt-1">{filteredSalesTotals.itemsSold}</span>
                <span className="text-[8px] text-slate-500 font-mono mt-0.5 block">scans</span>
              </div>
              <div className="bg-slate-950/30 p-2.5 rounded-xl border border-slate-800/80 text-left">
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider block">Avg Ticket</span>
                <span className="text-xs font-bold text-teal-400 block mt-1">₹{filteredSalesTotals.averageOrderValue}</span>
                <span className="text-[8px] text-slate-500 font-mono mt-0.5 block">per order</span>
              </div>
            </div>

            {orders.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">No customer orders logged yet.</div>
            ) : filteredOrders.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">No customer orders found in selected range.</div>
            ) : (
              <div className="space-y-2">
                {filteredOrders.map(order => (
                  <div
                    key={order.orderId}
                    className="p-3 bg-slate-950/60 rounded-2xl border border-slate-800 text-left space-y-2"
                  >
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="font-mono font-bold text-indigo-400">{order.orderId}</span>
                      <span className="text-slate-500">{new Date(order.createdAt).toLocaleDateString()}</span>
                    </div>

                    <div className="text-[11px] text-slate-300">
                      <p className="font-bold text-white mb-1">Customer: {order.customerName}</p>
                      {order.items.map((item: any, idx: number) => (
                        <div key={idx} className="flex justify-between text-slate-400">
                          <span>{item.productName} (x{item.quantity})</span>
                          <span>₹{item.lineTotal}</span>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-slate-800/80 pt-2 flex justify-between items-center text-[11px] font-bold">
                      <span className="text-slate-400">Received Amount:</span>
                      <span className="text-emerald-400">₹{order.totalAmount}</span>
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold ${
                        order.paymentStatus === "success" ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"
                      }`}>
                        Payment: {order.paymentStatus.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "settings" && (
          <div className="space-y-4">
            <form onSubmit={handleSaveSettings} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3.5 text-left">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 border-b border-slate-800 pb-2 flex items-center gap-1.5">
                <Settings className="w-3.5 h-3.5" /> Store Settings
              </h3>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Store Legal Name</label>
                <input
                  type="text"
                  required
                  placeholder="Store Name"
                  value={setStoreName}
                  onChange={(e) => setSetStoreName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Payment UPI ID (Merchant receiving address)</label>
                <input
                  type="text"
                  required
                  placeholder="username@upi"
                  value={setUpiId}
                  onChange={(e) => setSetUpiId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white font-mono"
                />
                <span className="text-[8px] text-slate-500 mt-0.5 block">Customer payments will be credited directly to this address.</span>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Low Stock Alert Threshold</label>
                <input
                  type="number"
                  required
                  placeholder="10"
                  value={setLowStock}
                  onChange={(e) => setSetLowStock(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Address</label>
                <textarea
                  placeholder="Store Address"
                  value={setAddress}
                  onChange={(e) => setSetAddress(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2.5 rounded-xl shadow-lg transition-all"
              >
                {submitting ? "Saving..." : "Save Configuration"}
              </button>
            </form>

            {/* Subscription Center */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3 text-left">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 border-b border-slate-800 pb-2 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5" /> Subscription Plan
              </h3>

              <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-indigo-300">{subscription?.planName || "Pro Monthly"}</span>
                  <span className="bg-indigo-600 text-white text-[8px] font-bold px-2 py-0.5 rounded-full uppercase">
                    {subscription?.status || "ACTIVE"}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 mt-2 space-y-0.5 font-mono">
                  <p>Charge: ₹{subscription?.amount} / plan period</p>
                  <p>Renew Date: {subscription?.endDate ? new Date(subscription.endDate).toLocaleDateString() : "N/A"}</p>
                </div>
              </div>

              {/* Alternative Plans */}
              <div className="grid grid-cols-2 gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => handleRenewSubscription("Pro Monthly Retailer", 299)}
                  className="p-2 border border-slate-800 hover:border-indigo-500/50 rounded-lg text-center bg-slate-900 transition-all"
                >
                  <p className="text-[10px] font-bold text-white">Monthly Plan</p>
                  <p className="text-[9px] text-indigo-400 font-bold">₹299/mo</p>
                </button>
                <button
                  type="button"
                  onClick={() => handleRenewSubscription("Premium Annual Master", 1999)}
                  className="p-2 border border-slate-800 hover:border-indigo-500/50 rounded-lg text-center bg-slate-900 transition-all relative"
                >
                  <span className="absolute -top-2 right-1 bg-amber-500 text-slate-950 text-[7px] font-bold px-1.5 py-0.2 rounded-full">POPULAR</span>
                  <p className="text-[10px] font-bold text-white">Annual Plan</p>
                  <p className="text-[9px] text-indigo-400 font-bold">₹1999/yr</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "ai" && (
          <div className="space-y-4">
            {/* AI Advisor Panel */}
            <div className="p-4 bg-gradient-to-br from-indigo-950/40 via-indigo-950/15 to-slate-950 rounded-2xl border border-indigo-500/25 text-left space-y-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/25">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white font-heading">Smart-QR AI Assistant</h3>
                  <p className="text-[9px] text-slate-400 font-mono uppercase tracking-wider">Gemini 3.5 Flash</p>
                </div>
              </div>

              <p className="text-[10px] text-slate-300 leading-relaxed">
                Connect directly with our server-side LLM engine. The AI will analyze your live SKU stock values, category counts, and sales history to compile personalized suggestions.
              </p>

              <button
                type="button"
                onClick={triggerGeminiInsights}
                disabled={aiLoading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5"
              >
                {aiLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Consulting Gemini...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Analyze Inventory Stock
                  </>
                )}
              </button>
            </div>

            {aiInsights && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-left space-y-3.5 shadow-xl">
                <div>
                  <h4 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block">Summary</h4>
                  <p className="text-xs text-white leading-relaxed mt-1 font-heading font-semibold">{aiInsights.inventorySummary}</p>
                </div>

                <div className="border-t border-slate-800 pt-3">
                  <h4 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mb-2">Restocking Suggestions</h4>
                  <div className="space-y-2">
                    {aiInsights.smartStockRecommendations?.map((rec: string, i: number) => (
                      <div key={i} className="flex gap-2 items-start text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/55">
                        <span className="bg-indigo-600/20 text-indigo-400 text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5">{i+1}</span>
                        <p className="leading-relaxed">{rec}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-3 text-xs text-slate-400">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mb-1">Billing Optimization Payout Tip</span>
                  <p className="leading-relaxed italic">"{aiInsights.payoutTip}"</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile Shell Tab Bar */}
      <div className="h-[52px] bg-slate-950/90 border-t border-slate-800/80 grid grid-cols-5 text-[9px] font-bold uppercase tracking-wider select-none shrink-0 z-10">
        <button
          onClick={() => { setActiveTab("inventory"); setShowAddForm(false); }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeTab === "inventory" ? "text-indigo-400" : "text-slate-500 hover:text-white"
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Items</span>
        </button>
        <button
          onClick={() => { setActiveTab("qrs"); }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeTab === "qrs" ? "text-indigo-400" : "text-slate-500 hover:text-white"
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>QRs</span>
        </button>
        <button
          onClick={() => { setActiveTab("orders"); }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeTab === "orders" ? "text-indigo-400" : "text-slate-500 hover:text-white"
          }`}
        >
          <ListOrdered className="w-4 h-4" />
          <span>Orders</span>
        </button>
        <button
          onClick={() => { setActiveTab("ai"); }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeTab === "ai" ? "text-indigo-400" : "text-slate-500 hover:text-white"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>AI Coach</span>
        </button>
        <button
          onClick={() => { setActiveTab("settings"); }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeTab === "settings" ? "text-indigo-400" : "text-slate-500 hover:text-white"
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Setup</span>
        </button>
      </div>
    </div>
  );
}
